#include "fc_io.h"
#include "fc_system.h"

//% hw_begin
FC_IO_Clk clk(100);
FC_IO_Reset reset(1);
//% hw_end

U32* test_register = (U32*) 0x40000000;

int main()
{
    (*test_register) += 0x12345678;
    while(1);
}

